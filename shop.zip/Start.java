public class Start{
    public static void main(String str[]){
		WelcomeWindow wl = new WelcomeWindow();
		wl.setVisible(true);
    }
}
