
import java.lang.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import javax.swing.table.*;

public class ViewProductActivity extends JFrame implements ActionListener  {
	private Customer customer;
	private JFrame activity;
	private Employee employee;
	private JScrollPane frame;
	JComboBox byWhatCB;
	JTable table;
	private JButton buttonLogout, buttonBack, buttonCheck, buttonAddProduct;
	private JLabel title, header, keywordLabel;
	JTextField keywordTF;
	private Font f1;
	private Font f2;
	public ViewProductActivity(JFrame prev, Customer customer) {
		super("View Product");
		
		this.setSize(800, 600);
		setBackground( new Color(214, 211, 211) );
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.activity = prev;
		this.customer = customer;
		
		f1 = new Font("ARIAL", Font.BOLD, 25);
		f2 = new Font("ARIAL", Font.BOLD, 15);
		
		title = new JLabel("View Product");
		title.setBounds(30, 40, 300,75);
		title.setOpaque(true);
		title.setBorder(new EmptyBorder(0,20,0,0));
		title.setFont(f1);
		title.setBackground(new Color(88, 24, 69));
		title.setForeground(Color.WHITE);
		add(title);
		
		buttonLogout = new JButton("Logout");
		buttonLogout.setBounds(660, 40, 100,30);
		buttonLogout.setBackground(new Color(88, 24, 69));
		buttonLogout.setForeground(Color.WHITE);
		buttonLogout.addActionListener(this);
		add(buttonLogout);
		
		buttonBack = new JButton("Back");
		buttonBack.setBounds(660, 80, 100,30);
	    buttonBack.setBackground(new Color(88, 24, 69));
		buttonBack.setForeground(Color.WHITE);
		buttonBack.addActionListener(this);
		add(buttonBack);
		
		keywordLabel = new JLabel("Keyword: ");
		keywordLabel.setBounds(60, 140, 140, 30);
		add(keywordLabel);
		
		keywordTF = new JTextField();
		keywordTF.setBounds(160, 140, 240, 30);
		add(keywordTF);
		
		byWhatCB = new JComboBox(new Object[]{"By ID", "By Name"});
		byWhatCB.setBounds(400, 140, 100,30);
		add(byWhatCB);
		
		buttonCheck = new JButton("Search");
		buttonCheck.setBounds(500, 140, 100,30);
		buttonCheck.setBackground(new Color(88, 24, 69));
		buttonCheck.setForeground(Color.WHITE);
		buttonCheck.addActionListener(this);
		add(buttonCheck);
		
		table = new JTable();
		DefaultTableModel model = new DefaultTableModel();
		model.setColumnIdentifiers(Product.columnNames);
		table.setModel(model);
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent evt) {
               jTable_ClickMouseClicked(evt);
            }
		});
		frame = new JScrollPane(table);
		frame.setBounds(40,185,600,300);
		add(frame);
		
		table.setModel(Product.searchProduct("", "By Name"));
		
		header = new JLabel();
		//header.setBackground(Theme.BACKGROUND_HEADER);
		header.setOpaque(true);
		header.setBounds(0, 0,800, 75);
		add(header);
		
		setSize(800,600);
		setLocation(100,100);
		setLayout(null);
	}
	
	public ViewProductActivity(JFrame prev, Employee employee) {
		super("View Product");
		
		this.setSize(800, 600);
		setBackground( new Color(214, 211, 211) );
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.activity = prev;
		this.employee = employee;
			title = new JLabel("View Product");
			
		title.setBounds(30, 40, 300,75);
		title.setOpaque(true);
		title.setBorder(new EmptyBorder(0,20,0,0));
		title.setFont(f1);
		title.setBackground(new Color(88, 24, 69));
		title.setForeground(Color.WHITE);
		add(title);
		
		buttonLogout = new JButton("Logout");
		buttonLogout.setBounds(660, 40, 100,30);
		buttonLogout.setBackground(new Color(88, 24, 69));
		buttonLogout.setForeground(Color.WHITE);
		buttonLogout.addActionListener(this);
		add(buttonLogout);
		
	    buttonBack = new JButton("Back");
		buttonBack.setBounds(660, 80, 100,30);
	    buttonBack.setBackground(new Color(88, 24, 69));
		buttonBack.setForeground(Color.WHITE);
		buttonBack.addActionListener(this);
		add(buttonBack);
		
		buttonAddProduct = new JButton("Add");
		buttonAddProduct.setBounds(660, 115, 100, 30);
		buttonAddProduct.setBackground(new Color(88, 24, 69));
		buttonAddProduct.setForeground(Color.WHITE);
		buttonAddProduct.addActionListener(this);
		add(buttonAddProduct);
		
		keywordLabel = new JLabel("Keyword: ");
		keywordLabel.setBounds(60, 140, 140, 30);
		add(keywordLabel);
		
		keywordTF = new JTextField();
		keywordTF.setBounds(160, 140, 240, 30);
		add(keywordTF);
		
		byWhatCB = new JComboBox(new Object[]{"By ID", "By Name"});
		byWhatCB.setBounds(400, 140, 100,30);
		add(byWhatCB);
		
		buttonCheck = new JButton("Search");
		buttonCheck.setBounds(500, 140, 100,30);
		buttonCheck.setBackground(new Color(88, 24, 69));
		buttonCheck.setForeground(Color.WHITE);
		buttonCheck.addActionListener(this);
		add(buttonCheck);
		
		table = new JTable();
		DefaultTableModel model = new DefaultTableModel();
		model.setColumnIdentifiers(Product.columnNames);
		table.setModel(model);
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent evt) {
               jTable_ClickMouseClicked(evt);
            }
		});
		frame = new JScrollPane(table);
		frame.setBounds(40,185,600,300);
		add(frame);
		
		table.setModel(Product.searchProduct("", "By Name"));
		
		header = new JLabel();
		//header.setBackground(Theme.BACKGROUND_HEADER);
		header.setOpaque(true);
		header.setBounds(0, 0,800, 75);
		add(header);
		
		
	}

	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource().equals(buttonLogout)) {
			this.setVisible(false);
			new Login().setVisible(true);
		}
		else if (ae.getSource().equals(buttonBack)) {
			this.setVisible(false);
			activity.setVisible(true);
		}
		else if (ae.getSource().equals(buttonCheck)) {
			table.setModel(Product.searchProduct(keywordTF.getText().trim(), byWhatCB.getSelectedItem().toString()));
		}
		else if (ae.getSource().equals(buttonAddProduct)) {
			this.setVisible(false);
			new AddProductActivity(this, employee).setVisible(true);
		}
		else {}
	}
	
	private void jTable_ClickMouseClicked(MouseEvent evt) {                                          
       int index = table.getSelectedRow();

       TableModel model = table.getModel();

       String value1 = model.getValueAt(index, 0).toString();
       
		if (customer!=null) {}
		else if (employee!=null)
			new ManageProduct(value1, this).setVisible(true);
		else {}
    }
}